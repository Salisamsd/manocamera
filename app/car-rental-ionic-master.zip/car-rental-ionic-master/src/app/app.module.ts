import {BrowserModule} from '@angular/platform-browser';
import {ErrorHandler, NgModule} from '@angular/core';
import {IonicApp, IonicErrorHandler, IonicModule} from 'ionic-angular';

import {MyApp} from './app.component';

import {StatusBar} from '@ionic-native/status-bar';
import {SplashScreen} from '@ionic-native/splash-screen';

import "rxjs/add/operator/map";
import "rxjs/add/operator/toPromise";
import {HttpModule} from "@angular/http";
import {CarsDetailsPage} from "../pages/cars-details/cars-details";
import {SchedulingPage} from "../pages/scheduling/scheduling";
import {CarProvider} from '../providers/car/car';

@NgModule({
  declarations: [
    MyApp,
    CarsDetailsPage,
    SchedulingPage
  ],
  imports: [
    BrowserModule,
    IonicModule.forRoot(MyApp),
    HttpModule
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,
    CarsDetailsPage,
    SchedulingPage
  ],
  providers: [
    StatusBar,
    SplashScreen,
    {provide: ErrorHandler, useClass: IonicErrorHandler},
    CarProvider
  ]
})
export class AppModule {
}
