export class Accessory {

  constructor(public name: string, public price: number) {

  }

}
