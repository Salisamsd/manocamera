import {Component} from '@angular/core';
import {NavController, NavParams} from 'ionic-angular';

/**
 * Generated class for the SchedulingPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */


@Component({
  selector: 'page-scheduling',
  templateUrl: 'scheduling.html',
})
export class SchedulingPage {

  public car;

  public totalPrice: number;

  public name: string;

  public address: string;

  public email: string;

  public date: string = new Date().toISOString();

  constructor(public navCtrl: NavController, public navParams: NavParams) {

    this.car = this.navParams.get('car');
    this.totalPrice = this.navParams.get('totalPrice');
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad SchedulingPage');
  }

  schedule() {

    console.log(this.name);
    console.log(this.address);
    console.log(this.email);
    console.log(this.date);

  }

}
