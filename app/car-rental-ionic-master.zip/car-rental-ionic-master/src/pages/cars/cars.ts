import {Component, OnInit} from '@angular/core';
import {AlertController, IonicPage, LoadingController, NavController, NavParams} from 'ionic-angular';
import {Http} from "@angular/http";
import {CarsDetailsPage} from "../cars-details/cars-details";

/**
 * Generated class for the CarsPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-cars',
  templateUrl: 'cars.html',
})
export class CarsPage implements OnInit {

  cars;

  constructor(public navCtrl: NavController,
              public navParams: NavParams,
              private _http: Http,
              private _loadCtrl: LoadingController,
              private _alertCtrl: AlertController) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad CarsPage');
  }

  ngOnInit() {

    let loader = this._loadCtrl.create({

      content: "Aguarde..."

    });

    loader.present();

    this._http

      .get('https://aluracar.herokuapp.com')

      .map(res => res.json())

      .toPromise()

      .then(cars => {

        this.cars = cars;

        loader.dismiss();

      }).catch(err => {

      console.log(err);

      loader.dismiss();

      let alert = this._alertCtrl.create({

        title: 'Falha na conexão',
        buttons: [{text: 'OK'}],
        subTitle: 'Não foi possível completar a requisição'
      });

      alert.present();

    });

  }

  selectCar(car) {

    console.log(car.nome);

    this.navCtrl.push(CarsDetailsPage, {carSelected: car});

  }

}
