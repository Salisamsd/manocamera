import {Component} from '@angular/core';
import {NavController, NavParams} from 'ionic-angular';
import {Accessory} from "../../domain/accessory";
import {SchedulingPage} from "../scheduling/scheduling";

/**
 * Generated class for the CarsDetailsPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@Component({
  selector: 'page-cars-details',
  templateUrl: 'cars-details.html',
})
export class CarsDetailsPage {

  car;

  accessories: Accessory[];

  private _totalPrice: number;

  constructor(public navCtrl: NavController, public navParams: NavParams) {

    this.car = this.navParams.get('carSelected');

    this._totalPrice = this.car.preco;

    this.accessories = [

      new Accessory('Freio ABS', 800),
      new Accessory('Ar-condicionado', 1000),
      new Accessory('MP3 Player', 500)
    ];
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad CarsDetailsPage');
  }

  get totalPrice() {

    return this._totalPrice;
  }

  updateTotal(turnedOn: boolean, accessory: Accessory) {

    turnedOn ? this._totalPrice += accessory.price : this._totalPrice -= accessory.price;

  }

  scheduling() {

    this.navCtrl.push(SchedulingPage, {

      car: this.car,
      totalPrice: this._totalPrice
    });
  }

}
