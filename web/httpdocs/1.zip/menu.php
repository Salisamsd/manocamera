 <nav class="navbar header-top fixed-top navbar-expand-lg  navbar-dark ">
      <a class="navbar-brand" href="#">MANOCAMERA.com</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarText" aria-controls="navbarText"
        aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarText">
        <ul class="navbar-nav side-nav">
          <li class="nav-item">
            <a class="nav-link" href="/main.php">Home
              <span class="sr-only">(current)</span>
            </a>
          </li>
       
          <li class="nav-item dropdown">
    <a class="nav-link dropdown-toggle" data-toggle="dropdown" href="" role="button" aria-haspopup="true" aria-expanded="false">DSLR</a>
    <div class="dropdown-menu" x-placement="bottom-start" style="position: absolute; transform: translate3d(0px, 40px, 0px); top: 0px; left: 0px; will-change: transform;">
      <a class="dropdown-item" href="/listDSLR.php">Action</a>
      <a class="dropdown-item" href="#">Another action</a>
      <a class="dropdown-item" href="#">Something else here</a>
      <div class="dropdown-divider"></div>
      <a class="dropdown-item" href="#">Separated link</a>
    </div>
  </li>
          <li class="nav-item">
            <a class="nav-link" href="/listMirrorless.php">MirrorLess</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="/listDSLR.php">Video</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="/listDSLR.php">Action</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="/listDSLR.php">All Accessory</a>
          </li>
          
        </ul>
        <ul class="navbar-nav ml-md-auto d-md-flex">
          
          <li class="nav-item">
              <a class="nav-link"  href="/index.html" ><img class="icon1" src="img/IKONS/PNG/32/logout.png">LOG OUT</a>
          </li>
        </ul>
      </div>
    </nav>